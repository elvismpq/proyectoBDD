package clasesAux;

import java.sql.*;
import javax.swing.JOptionPane;

public class Conector {

    static Connection contacto = null;

    public static Connection getConexion() {
        
        String url = "jdbc:mysql://localhost:3306/proyectoBDD?user=root&password=1234&useSSL=false";
        try {
            Class.forName("com.mysql.jdbc.Driver");

        } catch (ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
        try {
            contacto= DriverManager.getConnection(url,"root","1234");
            
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
        return contacto;
        }
    public static ResultSet Consulta(String consulta){
        Connection con = getConexion();
        Statement declara;
        try{
            declara=con.createStatement();
            ResultSet respuesta = declara.executeQuery(consulta);
            return respuesta;
        }catch(SQLException e){
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
        return null;  
    }
    
    }

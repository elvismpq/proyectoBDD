/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package proyectobdd;

import clasesAux.Conector;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import static proyectobdd.Usuario.res;

/**
 *
 * @author Elvis
 */
public class Contrayente1 extends javax.swing.JFrame {
    Conector con = new Conector();
    Connection cn = con.getConexion();
String prov,cprov,cant,ccant,cparr,parr,opcnac,opcLE,nomPais,cetnia,estciv,nivins;
Boolean aux=false,aux2=false ;
public static String cont1;
    public Contrayente1() throws SQLException {
        initComponents();
        CargarProv();
        CargarEtnia();
        CargarNivel();
        CargarEstado();
        txtpais.setVisible(false);
        lblpais.setVisible(false);
    }

    public void CargarProv() throws SQLException {
        
          res = Conector.Consulta("select Nombre_prov from provincia");
    try {
            while (res.next()) {
                this.comboxprov.addItem(res.getString(1));
                
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }      
          
    }
    public void CargarEtnia() throws SQLException {
        
          res = Conector.Consulta("select Nombre_Etnia from etniasm");
    try {
            while (res.next()) {
                this.comboxetnia.addItem(res.getString(1));
                
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }      
          
    }
    public void CargarNivel() throws SQLException {
        
          res = Conector.Consulta("select Nom_Niv_Inst from nivel_instruccion");
    try {
            while (res.next()) {
                this.comboxniv.addItem(res.getString(1));
                
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }      
          
    }
    public void CargarEstado() throws SQLException {
        
          res = Conector.Consulta("select Nombre_Estado from estadocivil");
    try {
            while (res.next()) {
                this.comboxestciv.addItem(res.getString(1));
                
                
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }      
          
    }
    public String CedCont1(){
    return cont1;
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        txtnom = new javax.swing.JTextField();
        txtCI = new javax.swing.JTextField();
        txtFecNac = new javax.swing.JTextField();
        comboxetnia = new javax.swing.JComboBox<>();
        comboxprov = new javax.swing.JComboBox<>();
        comboxniv = new javax.swing.JComboBox<>();
        comboxcant = new javax.swing.JComboBox<>();
        comboxparr = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtloc = new javax.swing.JTextArea();
        jSeparator1 = new javax.swing.JSeparator();
        lblpais = new javax.swing.JLabel();
        opcecu = new javax.swing.JRadioButton();
        opcext = new javax.swing.JRadioButton();
        txtpais = new javax.swing.JTextField();
        comboxestciv = new javax.swing.JComboBox<>();
        txtnummat = new javax.swing.JTextField();
        opcsi = new javax.swing.JRadioButton();
        opcno = new javax.swing.JRadioButton();
        BGuardar = new javax.swing.JButton();
        BAtras = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);

        jLabel1.setIcon(new javax.swing.ImageIcon("D:\\Respaldos2\\Documentos\\NetBeansProjects\\proyectoBDD\\hombre.png")); // NOI18N

        jLabel2.setText("Nombres y Apellidos:");

        jLabel3.setText("Nacionalidad:");

        jLabel4.setText("CI o Pasaporte:");

        jLabel5.setText("Fecha de Nacimiento:");

        jLabel7.setText("Anteriores Matrimonios:");

        jLabel8.setText("Estado Civil:");

        jLabel9.setText("Autoidentificacion etnica:");

        jLabel10.setText("¿Sabe leer y escribir? ");

        jLabel11.setText("Nivel de Instrucción:");

        jLabel12.setText("Residencia Habitual");

        jLabel13.setText("Provincia:");

        jLabel14.setText("Canton:");

        jLabel15.setText("Parroquia urbano o rural:");

        jLabel16.setText("Localidad:");

        txtnom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtnomActionPerformed(evt);
            }
        });

        txtCI.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtCIActionPerformed(evt);
            }
        });

        comboxetnia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione una opcion.." }));
        comboxetnia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboxetniaActionPerformed(evt);
            }
        });

        comboxprov.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione una provincia..." }));
        comboxprov.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboxprovActionPerformed(evt);
            }
        });

        comboxniv.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione una opcion.." }));
        comboxniv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboxnivActionPerformed(evt);
            }
        });

        comboxcant.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione un canton..." }));
        comboxcant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboxcantActionPerformed(evt);
            }
        });

        comboxparr.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione una parroquia.." }));
        comboxparr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboxparrActionPerformed(evt);
            }
        });

        txtloc.setColumns(20);
        txtloc.setRows(5);
        jScrollPane1.setViewportView(txtloc);

        lblpais.setText("Nombre Pais:");

        opcecu.setText("Ecuatoriano");
        opcecu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcecuActionPerformed(evt);
            }
        });

        opcext.setText("Extranjero");
        opcext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcextActionPerformed(evt);
            }
        });

        comboxestciv.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Seleccione una opcion.." }));
        comboxestciv.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboxestcivActionPerformed(evt);
            }
        });

        opcsi.setText("Si");
        opcsi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcsiActionPerformed(evt);
            }
        });

        opcno.setText("No");
        opcno.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                opcnoActionPerformed(evt);
            }
        });

        BGuardar.setText("Guardar");
        BGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BGuardarActionPerformed(evt);
            }
        });

        BAtras.setText("Atras");
        BAtras.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BAtrasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))
                                .addComponent(BGuardar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel1))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 8, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel8))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtnom, javax.swing.GroupLayout.PREFERRED_SIZE, 433, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                .addComponent(txtFecNac, javax.swing.GroupLayout.DEFAULT_SIZE, 149, Short.MAX_VALUE)
                                                .addComponent(txtCI))
                                            .addGap(39, 39, 39)
                                            .addComponent(jLabel3)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(opcext)
                                                .addComponent(opcecu))
                                            .addGap(51, 51, 51)))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(comboxestciv, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(50, 50, 50)
                                        .addComponent(lblpais)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtpais, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(43, 43, 43))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(224, 224, 224)
                                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 382, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addComponent(comboxetnia, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabel13))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(45, 45, 45)
                                                .addComponent(opcsi)
                                                .addGap(18, 18, 18)
                                                .addComponent(opcno)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jLabel14))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(0, 0, Short.MAX_VALUE)
                                                .addComponent(jLabel16))
                                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addGroup(layout.createSequentialGroup()
                                                        .addComponent(comboxniv, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                        .addGap(0, 0, Short.MAX_VALUE)
                                                        .addComponent(BAtras, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                                .addComponent(jLabel15)))
                                        .addGap(38, 38, 38))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(75, 75, 75)
                                        .addComponent(txtnummat, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(comboxprov, 0, 1, Short.MAX_VALUE)
                                        .addComponent(comboxcant, 0, 152, Short.MAX_VALUE)
                                        .addComponent(comboxparr, 0, 1, Short.MAX_VALUE))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(58, 58, 58))))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(jLabel12)
                        .addGap(152, 152, 152))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(txtnom, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(txtCI, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(opcecu))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(txtFecNac, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(opcext)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lblpais)
                                    .addComponent(txtpais, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(26, 26, 26)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(comboxestciv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8))))
                        .addGap(8, 8, 8)))
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(comboxetnia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel13)
                                .addComponent(comboxprov, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(comboxcant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel14))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel15)
                            .addComponent(comboxparr, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(BGuardar)
                                    .addComponent(BAtras))
                                .addGap(22, 22, 22))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(16, 16, 16)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel10)
                            .addComponent(opcsi)
                            .addComponent(opcno))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(comboxniv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel11))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7)
                            .addComponent(txtnummat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                        .addComponent(jLabel16)
                        .addGap(105, 105, 105))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtnomActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtnomActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtnomActionPerformed

    private void txtCIActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtCIActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtCIActionPerformed

    private void opcsiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcsiActionPerformed
     if(opcsi.isSelected())
            opcno.setSelected(false);
        opcsi.setSelected(true);
        opcLE="Si";
    }//GEN-LAST:event_opcsiActionPerformed

    private void BGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BGuardarActionPerformed
        
        if(txtpais.getText().equals("")){
            nomPais="null";
        }else{
            nomPais=txtpais.getText();
        }
        cont1=txtCI.getText();
        try {
            
            PreparedStatement pps = cn.prepareStatement("INSERT INTO `proyectobdd`.`contrayente1` (`Ced_cont1`, `Nom_Comp`, `Nacionalidad`, `Nom_pais`, `Fec_Nac`, `Num_mat`, `idEstadocivil`, `idEtnias`, `Leer_Escribir`, `Localidad`, `idparroquia`, `idnivel_instr`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?);");
            pps.setString(1, txtCI.getText());
            pps.setString(2, txtnom.getText());
            pps.setString(3, opcnac);
            pps.setString(4, nomPais);
            pps.setString(5, txtFecNac.getText());
            pps.setString(6, txtnummat.getText());
            pps.setString(7, estciv);
            pps.setString(8, cetnia);
            pps.setString(9, opcLE);
            pps.setString(10, txtloc.getText());
            pps.setString(11, cparr);
            pps.setString(12, nivins);
            JOptionPane.showMessageDialog(null, "Datos Guardados");
            int resp = pps.executeUpdate();
            if (resp < 0) {
                JOptionPane.showMessageDialog(null, "Error al ingresar");
            }

        } catch (Exception e) {
            System.out.println(e);
        }
        this.dispose();
    }//GEN-LAST:event_BGuardarActionPerformed

    private void opcecuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcecuActionPerformed
       if(opcecu.isSelected())
            opcext.setSelected(false);
        opcecu.setSelected(true);
        opcnac="Ecuatoriano";
        txtpais.setVisible(false);
        lblpais.setVisible(false);
    }//GEN-LAST:event_opcecuActionPerformed

    private void comboxprovActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboxprovActionPerformed
  comboxcant.removeAllItems();
      aux=false;
      this.comboxcant.addItem("Seleccione un canton...");
        prov=comboxprov.getSelectedItem().toString();
     res = Conector.Consulta("select idprovincia from provincia where Nombre_prov='"+prov+"'");
     try { 
          while(res.next()){
                cprov=res.getString(1);
      }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
     
     res = Conector.Consulta("select nom_cant from cantones where idprovincia='"+cprov+"'");
     try { 
          while(res.next()){
                 this.comboxcant.addItem(res.getString(1));
      }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
     aux=true;        // TODO add your handling code here:
    }//GEN-LAST:event_comboxprovActionPerformed

    private void comboxcantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboxcantActionPerformed
           if(aux){ 
        comboxparr.removeAllItems();
     this.comboxparr.addItem("Seleccione una parroquia..."); 
     cant=comboxcant.getSelectedItem().toString();
     res = Conector.Consulta("select idcanton from cantones where nom_cant='"+cant+"'");
     try { 
          while(res.next()){
                ccant=res.getString(1);
      }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
     
     res = Conector.Consulta("select nom_parr from parroquia where idcanton='"+ccant+"'");
     try { 
          while(res.next()){
                 this.comboxparr.addItem(res.getString(1));
      }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
         aux2=true; 
           }
    }//GEN-LAST:event_comboxcantActionPerformed

    private void opcextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcextActionPerformed
       if(opcext.isSelected())
            opcecu.setSelected(false);
        opcext.setSelected(true);
        opcnac="Extranjero";
        txtpais.setVisible(true);
        lblpais.setVisible(true);
    }//GEN-LAST:event_opcextActionPerformed

    private void opcnoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_opcnoActionPerformed
        if(opcno.isSelected())
            opcsi.setSelected(false);
        opcno.setSelected(true);
        opcLE="No";
    }//GEN-LAST:event_opcnoActionPerformed

    private void comboxparrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboxparrActionPerformed
       if(aux2){ 
        parr=comboxparr.getSelectedItem().toString();
    res = Conector.Consulta("select idparroquia from parroquia where nom_parr='"+parr+"'");
     try { 
          while(res.next()){
                cparr=res.getString(1);
      }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }}
    }//GEN-LAST:event_comboxparrActionPerformed

    private void comboxetniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboxetniaActionPerformed
      cetnia=comboxetnia.getSelectedItem().toString();
    res = Conector.Consulta("select idEtnias from etniasm where Nombre_Etnia='"+cetnia+"'");
     try { 
          while(res.next()){
                cetnia=res.getString(1);
      }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_comboxetniaActionPerformed

    private void comboxnivActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboxnivActionPerformed
        nivins=comboxniv.getSelectedItem().toString();
    res = Conector.Consulta("select Cod_Niv from nivel_instruccion where Nom_Niv_Inst='"+nivins+"'");
     try { 
          while(res.next()){
                nivins=res.getString(1);
      }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_comboxnivActionPerformed

    private void comboxestcivActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboxestcivActionPerformed
        estciv=comboxestciv.getSelectedItem().toString();
    res = Conector.Consulta("select idEstadocivil from estadocivil where Nombre_Estado='"+estciv+"'");
     try { 
          while(res.next()){
                estciv=res.getString(1);
      }
           System.out.println(estciv); 
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "No se pudo establecer la conexion" + e.getMessage(), "Error de Conexion", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_comboxestcivActionPerformed

    private void BAtrasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BAtrasActionPerformed
        this.dispose();
    }//GEN-LAST:event_BAtrasActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Contrayente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Contrayente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Contrayente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Contrayente1.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new Contrayente1().setVisible(true);
                } catch (SQLException ex) {
                    Logger.getLogger(Contrayente1.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BAtras;
    private javax.swing.JButton BGuardar;
    private javax.swing.JComboBox<String> comboxcant;
    private javax.swing.JComboBox<String> comboxestciv;
    private javax.swing.JComboBox<String> comboxetnia;
    private javax.swing.JComboBox<String> comboxniv;
    private javax.swing.JComboBox<String> comboxparr;
    private javax.swing.JComboBox<String> comboxprov;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblpais;
    private javax.swing.JRadioButton opcecu;
    private javax.swing.JRadioButton opcext;
    private javax.swing.JRadioButton opcno;
    private javax.swing.JRadioButton opcsi;
    private javax.swing.JTextField txtCI;
    private javax.swing.JTextField txtFecNac;
    private javax.swing.JTextArea txtloc;
    private javax.swing.JTextField txtnom;
    private javax.swing.JTextField txtnummat;
    private javax.swing.JTextField txtpais;
    // End of variables declaration//GEN-END:variables
}
